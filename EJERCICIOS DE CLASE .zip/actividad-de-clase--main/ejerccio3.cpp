
#include <iostream>
using namespace std;

int main() {
    int A = 5;
    int B = 10;
    A += 3;
    B -= A;
    cout << A << ", " << B << endl;
    return 0;
}
